# HelpMeDoc

An AI-powered Korean medical assistant chatbot designed for foreigners living in Korea.

Features:
- Symptom-based GPT chatbot
- OCR image upload and medication explanation
- Simple, Streamlit-powered interface

Deploy this app using Streamlit Cloud for quick web access.

GitHub: https://github.com/Rockyrockyzzz/helpmedoc